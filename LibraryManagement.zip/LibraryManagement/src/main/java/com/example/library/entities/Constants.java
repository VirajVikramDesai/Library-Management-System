package com.example.library.entities;

import java.util.ArrayList;

public class Constants {

	public Constants() {

	}

	public static String USERNAME = "Admin";
	public static String PASSWORD = "P";
	public static String USERNAME1 = "A";
	public static String PASSWORD1 = "B";
	public static int FINE_PER_DAY = 5;
	public static int RETURN_DURATION = 1;
	public static int BOOK_LIMIT = 4;
	public static String SESSION_ADMIN = "ADMIN";
	
	public static String SESSION_OK = "SOK";
	
	public static String SESSION_NOTOK = "SNOTOK";

	// Categories
	public static ArrayList<String> getAllCategories() {
		ArrayList<String> categories = new ArrayList<String>();
		categories.add("JAVA");
		categories.add("DATABASE TECH");
		categories.add("DATA STRUCTURE");
		categories.add("PYTHON");
		categories.add("EMBEDED SYSTEM");
		categories.add("WEB TECHNOLOGY");
		categories.add("OTHER");

		return categories;
	}

	// Branches
	public static ArrayList<String> getAllBranches() {
		ArrayList<String> branches = new ArrayList<String>();
		branches.add("PG-DAC");
		branches.add("PG-DBDA");
		branches.add("PG-DESD");
		branches.add("PG-DITISS");
		branches.add("PG-DIOT");
		branches.add("OTHER");

		return branches;
	}

	// Years
	public static ArrayList<String> getAllYears() {
		ArrayList<String> years = new ArrayList<String>();
		years.add("March");
		years.add("September");
		

		return years;
	}

	// Divisions
	public static ArrayList<String> getAllDivision() {
		ArrayList<String> divisions = new ArrayList<String>();
		divisions.add("KP");
		divisions.add("EC");
		

		return divisions;
	}

}
